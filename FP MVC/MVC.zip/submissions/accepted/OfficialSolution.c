#include<stdio.h>
#include<string.h>
#include<math.h>

int max(char num1[], int size1, char num2[], int size2){
    if (size1>size2) return 1;
    else if (size1==size2) {
        int i;
        for (i=0; i<size1; i++){
            if (num1[i]>num2[i]) return 1;
            else if (num1[i]<num2[i]) return 0;
        }
    }

    return 0;
}

void sort(char arr[], int n){
    int i, j;
    char temp; 
    for (i = 0; i < n; i++){
        for (j = i + 1; j < n; j++){
            if (arr[i] < arr[j]){
                temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }
    }
}

int main() {
    char str[500];
    int k, n;

    scanf("%s", str);
    getchar();
    scanf("%d", &k);
    n = strlen(str);

    int max_size = 0;
    char max_sum[20];

    for (int i = 0; i < n - k + 1; i++) {
        char arr[k], ctr = 0;
        
        for (int j = 0; j < k; j++)
            if(str[i + j] >= '0' && str[i + j] <= '9')
                arr[ctr++] = str[i + j];

        sort(arr, ctr);
        if(max(arr, ctr, max_sum, max_size)){
            max_size = ctr;
            strcpy(max_sum, arr);
        }
    }

    for (int i = 0; i < max_size; i++){
        printf("%c", max_sum[i]);
    }
    
    return 0;
}